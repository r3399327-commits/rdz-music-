# RDZ Music
Site/app web do MC RDZINHO.

## Como usar
Abra `index.html` em um navegador para testar.
Para instalar como app na tela inicial e compartilhar com amigos, publique esta pasta em um serviço de hospedagem HTTPS (por exemplo, GitHub Pages) e abra o endereço no Chrome.

## Importante
Esta versão é um protótipo local: os lançamentos ficam salvos no aparelho/navegador. Ela NÃO envia músicas de verdade para Spotify, Apple Music ou outras plataformas. Para distribuição real, é necessário usar uma distribuidora.
